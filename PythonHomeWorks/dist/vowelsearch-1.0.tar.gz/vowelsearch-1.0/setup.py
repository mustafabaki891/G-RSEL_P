from setuptools import setup
setup(
    name="vowelsearch",
    version="1.0",
    py_modules=["vowelsearch"]
)